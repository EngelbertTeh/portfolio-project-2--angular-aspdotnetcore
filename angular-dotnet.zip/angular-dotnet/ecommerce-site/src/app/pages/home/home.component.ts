import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { PaginatorModule } from 'primeng/paginator';
import { Product, Products } from '../../../types';
import { ProductComponent } from '../../components/product/product.component';
import { ProductsService } from '../../services/products.service';

interface PaginatorParams {
  page?: number;
  rows?: number;
  first?: number;
  pageCount?: number;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ProductComponent, CommonModule, PaginatorModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  constructor(private productsService: ProductsService) {}

  products: Product[] = [];

  totalRecords: number = 0;

  rows: number = 5;

  onProductOutput(product: Product) {
    console.log(product, 'output');
  }

  onPageChange({ page, rows }: PaginatorParams) {
    this.fetchProducts(page!, rows!);
  }

  fetchProducts(page: number, perPage: number): Product[] {
    this.productsService
      .getProducts('http://localhost:5021/api/product', {
        page: page,
        perPage: perPage,
      })
      .subscribe((payload: Products) => {
        const products = {
          items: payload.items,
          total: payload.total,
          page: payload.page,
          perPage: payload.perPage,
          totalPages: payload.totalPages,
        };

        this.products = products.items;
        this.totalRecords = products.total;
      });
    return this.products;
  }

  ngOnInit() {
    this.fetchProducts(0, this.rows);
  }
}
