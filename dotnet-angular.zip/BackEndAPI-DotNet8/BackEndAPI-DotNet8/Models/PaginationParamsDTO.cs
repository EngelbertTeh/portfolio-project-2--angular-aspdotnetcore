﻿namespace BackEndAPI_DotNet8.Models
{
    public class PaginationParamsDTO
    {
        public int Page { get; set; }
        public int PerPage { get; set; }
    }
}
