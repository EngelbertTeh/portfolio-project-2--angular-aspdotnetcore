﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BackEndAPI_DotNet8.Models
{
    public class Product
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Price { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Image { get; set; } = string.Empty;
        public int Rating { get; set; }

    }
}
