﻿using System.Runtime.InteropServices;

namespace BackEndAPI_DotNet8.Models
{
    public class ProductsDTO
    {

        public Product[] Items { get; set; } = [];
        public int Total { get; set; }
        public int Page { get; set; }
        public int PerPage { get; set; }
        public int TotalPages { get; set; }




    }
}
