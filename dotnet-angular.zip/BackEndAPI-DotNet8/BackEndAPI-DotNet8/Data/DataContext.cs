﻿using BackEndAPI_DotNet8.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using System.Reflection.Metadata;

namespace BackEndAPI_DotNet8.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base (options)
        {

        }


        /** protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<House>()
                .HasMany(e => e.Room)
                .WithOne(e => e.House)
                .HasForeignKey(e => e.HouseId)
                .IsRequired();
        }
        Use this if require relationship mapping between entities/models
        **/
        public DbSet<Product> Products {  get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            SeedInitialData(modelBuilder);
        }

        private void SeedInitialData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Black Hoodie", Price = "55", Image = "https://m.media-amazon.com/images/I/61DxPMSKUxL._AC_SX679_.jpg", Rating = 5 },
                new Product { Id = 2, Name = "Branded Shoes", Price = "200", Image = "https://m.media-amazon.com/images/I/71wtZyOcJPL._AC_SY575_.jpg", Rating = 5 },
                new Product { Id = 3, Name = "White Shirt", Price = "35", Image = "https://m.media-amazon.com/images/I/61W+GNctq7L._AC_SX466_.jpg", Rating = 3 },
                new Product { Id = 4, Name = "Gray Dress", Price = "125", Image = "https://m.media-amazon.com/images/I/51LRyPuWEkL._AC_SY741_.jpg", Rating = 4 },
            new Product { Id = 5, Name = "Black T-Shirt (Mens)", Price = "15", Image = "https://m.media-amazon.com/images/I/71yFQ5q7zKL._AC_SX569_.jpg", Rating = 3 },
             new Product { Id = 6, Name = "Cool Shorts", Price = "10", Image = "https://m.media-amazon.com/images/I/71PafBDUIML._AC_SX679_.jpg", Rating = 3 }
           );

            // Add more seeding data as needed
        }
    }
}
