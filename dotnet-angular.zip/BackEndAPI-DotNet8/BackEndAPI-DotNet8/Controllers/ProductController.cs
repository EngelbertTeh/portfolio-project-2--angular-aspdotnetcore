﻿using BackEndAPI_DotNet8.Models;
using BackEndAPI_DotNet8.Services;
using Microsoft.AspNetCore.Mvc;


namespace BackEndAPI_DotNet8.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        
        private readonly ProductService _productService;

        public ProductController ( ProductService productService)
        {
     
            _productService = productService;
        }


        [HttpGet]
        public async Task<ActionResult<ProductsDTO>> GetProducts([FromQuery(Name ="page")] int page, [FromQuery(Name = "perPage")] int perPage)
        {
            PaginationParamsDTO paramsDTO = new PaginationParamsDTO
            {
                Page = page,
                PerPage = perPage,
            };
            ProductsDTO productsDTO = await _productService.GetProducts(paramsDTO);
            return Ok(productsDTO);
        }


        [HttpPost]
        public async Task<ActionResult<List<Product>>> AddProduct(Product newProduct)
        {
            await _productService.AddProduct(newProduct);
            return Created();
        }
    }
}
