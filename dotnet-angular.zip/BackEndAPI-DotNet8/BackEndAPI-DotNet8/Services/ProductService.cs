﻿using BackEndAPI_DotNet8.Data;
using BackEndAPI_DotNet8.Models;
using Microsoft.EntityFrameworkCore;

namespace BackEndAPI_DotNet8.Services
{
    public class ProductService
    {
        private readonly DataContext _context ;
        public ProductService(DataContext context)
        {
            _context = context;
        }
        public async Task<ProductsDTO> GetProducts(PaginationParamsDTO paramsDTO)
        {
            int count = await _context.Products.CountAsync();
            int totalPages = (int)Math.Ceiling(count / (double)paramsDTO.PerPage);
            int itemsToSkip = paramsDTO.Page * paramsDTO.PerPage;

            Product[] products = await _context.Products.Skip(itemsToSkip).Take(paramsDTO.PerPage).ToArrayAsync();
            ProductsDTO productsDTO = new ProductsDTO
            {
                Items = products,
                Total = count,
                Page = paramsDTO.Page + 1,
                PerPage = paramsDTO.PerPage,
                TotalPages = totalPages,

            };
        
            
            return productsDTO; 

        }

        public async Task AddProduct(Product newProduct)
        {
            _context.Products.Add(newProduct);
            await _context.SaveChangesAsync();
        }
    }
}
